from tkinter import *

v_test=Toplevel()
v_test.title("Formula-E")
v_test.geometry("700x600")

Img3=PhotoImage(file="fondo2img.png")
Lb_P3= Label(v_test,image=Img3).place(x=260,y=200)

