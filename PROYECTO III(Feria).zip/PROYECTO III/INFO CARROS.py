from tkinter import *
from tkinter import ttk

fondo2= "#99CCFF"
textomorado= "#333399"

def asignar_carro(car,EF):
    global carros
    if(car=="Tesla"):
        carros[0][0]=EF
        ordenar_REP_RGP(0,0)
        
    elif(car=="Ferrari"):
        carros[1][0]=EF
        ordenar_REP_RGP(0,0)
        
    elif(car=="McLaren"):
        carros[2][0]=EF
        ordenar_REP_RGP(0,0)
        
    elif(car=="Porshe"):
        carros[3][0]=EF
        ordenar_REP_RGP(0,0)
        
    elif(car=="VolksWagen"):
        carros[4][1]=EF
        ordenar_REP_RGP(0,0)
        
    elif(car=="Maserati"):
        carros[5][1]=EF
        ordenar_REP_RGP(0,0)

    else:
        ''
        
        

def editar_ef():

    def select_car():
        car=SpinB_carro.get()
        asignar_carro(car,EF)

    v_ef=Toplevel()
    v_ef.title("Formula-E")
    v_ef.geometry("500x400")
    v_ef.configure(background=fondo2)

    EF=IntVar()

    Lb_titulo=Label(v_ef,text="Editar Información de los Automoviles",font=("Cambria",18),fg=textomorado,background=fondo2).place(x=50,y=5)

    Lb_sel=Label(v_ef,text="Seleccione el automóvil en el que desea realizar cambios:",font=("News Gothic",12),background=fondo2).place(x=30,y=80)

    SpinB_carro=ttk.Combobox(v_ef,values=("Tesla","Ferrari","McLaren","Porshe","VolksWagen","Maserati"))
    SpinB_carro.current(0)
    SpinB_carro.place(x=40,y=120)

    Lb_ef=Label(v_ef,text="Eficiencia del Carro:",font=("News Gothic",12),background=fondo2).place(x=30,y=200)

    En_ef=Entry(v_ef,textvariable=EF).place(x=40,y=240)

    Lb_unit=Label(v_ef,text="Km/KWh",background=fondo2).place(x=175,y=237)

    Bt_Save=Button(v_ef,text="Guardar Cambios",command=select_car,width=20,height=2).place(x=30,y=350)

    Bt_seguir=Button(v_ef,text="Ver Ranking",command=llamar,width=20,height=2).place(x=200,y=350)


    
editar_ef()
    

    
