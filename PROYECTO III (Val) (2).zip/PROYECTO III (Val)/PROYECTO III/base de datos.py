import sqlite3
a=["Florentino",25]

conexion=sqlite3.connect("base_datos")
puntero=conexion.cursor()
puntero.execute("INSERT INTO Ranking (Nombre,Edad) VALUES (?,?)",a)                
                
#"CREATE TABLE ranking(nombre VARCHAR(30),edad INTEGER)"
#UPDATE ranking SET edad=(?) WHERE nombre=(?)
#SELECT edad FROM ranking WHERE ...

conexion.commit()
conexion.close()

#
