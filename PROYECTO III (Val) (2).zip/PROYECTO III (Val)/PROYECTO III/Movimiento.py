
from tkinter import *               

from threading import Thread        

import threading                     

import os                           

import time                         

from tkinter import messagebox      

import tkinter.scrolledtext as tkscrolled

##### Biblioteca para el Carro

from WiFiClient import NodeMCU

myCar = NodeMCU()

myCar.start()

msjRec=""

msjEnv=""



def Up():
    print("Avanza")
    return enviar("pwm:1000")

def Down():
    print("Retrocede")
    return enviar("pwm:-1000")

def Left():
    print("Izquierda")
    enviar("pwm:1000")
    enviar("dir:-1")

def Right():
    print("Derecha")
    enviar("pwm:-1000")
    enviar("dir:1")
    
    

def obIn():

    indice=0

    while(myCar.loop):

        while(indice < len(myCar.log)):

            global msjRec

            global msjEnv

            """myCar.Log[indice] es el mensaje de respuesta([0]) o

                de envío de msj ([1]), estos valores son consecuentes

                respecto al comando, así que respecto a estas variables

                se harán las acciones de los eventos(comandos)

                """

            msjRec = myCar.log[indice][0]

            msjEnv = myCar.log[indice][1]

            print(msjRec,msjEnv)

            indice+=1

        time.sleep(0.200)

    p = Thread(target=get_log)

    p.start()


def enviar(x):

    """x está funcionando como comandos (cambiar por eventos en la interfaz)

    ya sea botones o teclas que equivalgan a los comandos"""

    if(isinstance(x,str)):

        myCar.send(x)

        """este return no es necesario a la hora de hacer la parte

        gráfica se soluciona con el main loop de tkinter"""

        return obIn()

    else:

        return False


TD=Tk()
TD.geometry('550x500')

Bt_avanza=Button(TD,text='Avanzar',command= Up).place(x=275,y=100)

Bt_retroceso=Button(TD,text='Retroceder',command= Down).place(x=200,y=200)
                                                              
Bt_izquierda=Button(TD,text='Izquierda',command= Left).place(x=400,y=200)

Bt_derecha= Button(TD,text='Derecha',command= Right).place(x=275,y=300)


