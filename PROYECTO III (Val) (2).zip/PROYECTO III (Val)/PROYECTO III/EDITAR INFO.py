from tkinter import *
import tkinter as tk
from tkinter import ttk
import tkinter.font as tkFont

fondo2= "#99CCFF"
textomorado= "#333399"

PILOT=''

def REP_RGP(V,T,A,P):
    print("REP")
    V=V.get()
    T=T.get()
    A=A.get()
    P=P.get()
    
    rep=int((V/(T-A))*100)
    print("El REP es:",rep)

    rgp=int(((V+P)/(T-A))*100)
    print("El RGP es:",rgp)

    return rep

def asignar_piloto(rep,rgp):
    if(PILOT=="Florentino"):
        
    
    


def editar_info():

    def select_pilot():
        global PILOT
        PILOT= SpinB_piloto.get()
        REP_RGP(V,T,A,P)
        
    v_info=Tk()
    v_info.title("Formula-E")
    v_info.geometry("700x600")
    v_info.configure(background=fondo2)

    V=IntVar()
    A=IntVar()
    T=IntVar()
    P=IntVar()

    Lb_titulo=Label(v_info,text="Editar Información",font=("Cambria",18),fg=textomorado,background=fondo2).place(x=280,y=5)

    Lb_titulo=Label(v_info,text="Seleccione el piloto en el que desea realizar cambios",font=("News Gothic",12),background=fondo2).place(x=70,y=100)

    SpinB_piloto=ttk.Combobox(v_info,values=("Florentino","Smyrno","Francesca","Nil","Alaiah","PineBerry"))
    
    SpinB_piloto.current(0)
    SpinB_piloto.place(x=70,y=140)


    Lb_V=Label(v_info,text="Cantidad de Victorias:",font=("News Gothic",12),background=fondo2).place(x=70,y=200)

    En_V=Entry(v_info,textvariable=V).place(x=70,y=240)

    Lb_P=Label(v_info,text="Cantidad de 2do y 3er lugar:",font=("News Gothic",12),background=fondo2).place(x=70,y=400)

    En_P=Entry(v_info,textvariable=P).place(x=70,y=440)

    Lb_A=Label(v_info,text="Cantidad de Abandonos:",font=("News Gothic",12),background=fondo2).place(x=300,y=200)

    En_A=Entry(v_info,textvariable=A).place(x=300,y=240)

    Lb_T=Label(v_info,text="Carreras en las que ha participado:",font=("News Gothic",12),background=fondo2).place(x=300,y=400)

    En_T=Entry(v_info,textvariable=T).place(x=300,y=440)

    Bt_Save=Button(v_info,text="Guardar Cambios",command=select_pilot,width=20,height=2).place(x=70,y=500)

editar_info()
